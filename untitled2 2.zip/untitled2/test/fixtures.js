export const aoife = {
    firstName: "Aoife",
    lastName: "Byrne",
    email: "aoife@byrne.com",
    password: "secret",
};

export const testUsers = [
    {
        firstName: "Sean",
        lastName: "Hutchinson",
        email: "sean@hutchinson.com",
        password: "mattblack",
    },
    {
        firstName: "Rachel",
        lastName: "Duffy",
        email: "rachel@duffy.com",
        password: "blonde",
    },
    {
        firstName: "Aoife",
        lastName: "Haden",
        email: "aoife@haden.com",
        password: "camera",
    },
];

export const kildare = {
    title: "Kildare",
};

export const testCategories = [
    {
        title: "Galway",
    },
    {
        title: "Dublin",
    },
    {
        title: "Cork",
    },
    {
        title: "Donegal",
    },
];

export const slieveWyle = {
    title: "slieveWyle",
    lat: "107",
    long: "115",
    county: "Meath",
    translation: "Here lies Borun, King of Slieve",
};

export const testOghams = [
    {
        title: "Offaly Ogham",
        lat: "25",
        long: "99",
        county: "Offaly",
        translation: "lorem ipsum dolor set",
    },
    {
        title: "CarryBeg Ogham",
        lat: "23",
        long: "99",
        county: "Fermanagh",
        translation: "lorem ipsum dolor set",
    },
    {
        title: "Cavan Ogham",
        lat: "90",
        long: "90",
        county: "Cavan",
        translation: "lorem ipsum dolor set",
    },
];
